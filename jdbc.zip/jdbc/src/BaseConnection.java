import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class BaseConnection extends JFrame implements ActionListener {
    private JTextField txtuname, txtupassword, txtubirthdate,txtusex, txtuage, txtuemail, txtuhobby;
    private JButton btnRegister, btnLogin;
    private Connection con;
    //Statement stmt;
    //ResultSet rs;
    //�������ݿ�
    private void connectMyDB() throws SQLException {
        //�������ݿ��׼��
        String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver";
        String dbURL="jdbc:sqlserver://localhost:1433;DatabaseName=MyDataBase";  // �ҵ����ݿ��� Test
        String userName="sa";   // ��д����û������ҵ���sa
        String userPwd="123456";   // ��д�������
        //Connection con;
        try{
            //������������
            Class.forName(driverName);
            //������ݿ�����
            con = DriverManager.getConnection(dbURL,userName,userPwd);
            //stmt = con.createStatement();
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("���ݿ�����ʧ��!");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("���ݿ�����ʧ��!");
        }
    }
    //�����û���Ϣ
    private boolean insertuser (String uname, String upassword, String usex,String ubirthdate, int uage, String uemail,
                                String uhobby) {
        boolean success = false;
        try {
            connectMyDB();
            // �����û���Ϣ
            String query = "INSERT INTO MyUser (uname, upassword,usex, ubirthdate, uage, uemail, uhobby) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, uname);
            stmt.setString(2, upassword);
            stmt.setString(3, usex);
            stmt.setString(4, ubirthdate);
            stmt.setInt(5, uage);
            stmt.setString(6, uemail);
            stmt.setString(7, uhobby);


            int rowsAffected = stmt.executeUpdate();


            // ����ɹ�������true
            if (rowsAffected > 0) {
                success = true;
            }


            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return success;
    }
    //��������Ƿ��ظ�
    private boolean checkunameExist(String username) {
        boolean exist = false;
        try {
            connectMyDB();
            String query = "SELECT uname FROM [user] WHERE uname=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            // �����ѯ�����Ϊ�գ����ʾ�û����Ѵ���
            if (rs.next()) {
                exist = true;
            }
            stmt.close();
            rs.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exist;
    }
    //��ѯ�Ƿ���Ե�¼
    private boolean checkUser(String username, String password) {
        boolean success = false;
        try {
            connectMyDB();
            String query = "SELECT uname,upassword FROM [user] WHERE uname=? AND upassword=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            // �����ѯ�����Ϊ�գ����ʾ��¼��Ϣ��Ч
            if (rs.next()) {
                success = true;
            }
            stmt.close();
            rs.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return success;
    }

    public BaseConnection() {

        setTitle("�û�ע�����¼");

        setSize(500, 450);

        // ���񲼾�
        setLayout(new GridLayout(9,1));

        JLabel lblUsername = new JLabel("�û���:");
        txtuname = new JTextField();
        add(lblUsername);
        add(txtuname);

        JLabel lblPassword = new JLabel("����:");
        txtupassword = new JTextField();
        add(lblPassword);
        add(txtupassword);

        JLabel lblSex = new JLabel("�Ա�:");
        txtusex = new JTextField();
        add(lblSex);
        add(txtusex);

        JLabel lblBirthdate = new JLabel("��������:");
        txtubirthdate = new JTextField();
        add(lblBirthdate);
        add(txtubirthdate);

        JLabel lblAge = new JLabel("����:");
        txtuage = new JTextField();
        add(lblAge);
        add(txtuage);

        JLabel lblEmail = new JLabel("����:");
        txtuemail = new JTextField();
        add(lblEmail);
        add(txtuemail);

        JLabel lblHobbies = new JLabel("����:");
        txtuhobby = new JTextField();
        add(lblHobbies);
        add(txtuhobby);


        btnRegister = new JButton("ע��");
        btnRegister.addActionListener(this);
        add(btnRegister);


        btnLogin = new JButton("��¼");
        btnLogin.addActionListener(this);
        add(btnLogin);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnRegister) {

            String uname = txtuname.getText().trim();
            String upassword = txtupassword.getText().trim();
            String usex = txtusex.getText().trim();
            String ubirthdate = txtubirthdate.getText().trim();
            int uage = Integer.parseInt(txtuage.getText().trim());
            String uemail = txtuemail.getText().trim();
            String uhobby = txtuhobby.getText().trim();


            if (checkunameExist(uname)) {
                JOptionPane.showMessageDialog(this, "�û����Ѵ��ڣ�����������", "ע��ʧ��", JOptionPane.ERROR_MESSAGE);
                return;
            }


            if (insertuser(uname, upassword, usex, ubirthdate, uage, uemail, uhobby)) {
                JOptionPane.showMessageDialog(this, "ע��ɹ�", "ע����", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "ע��ʧ�ܣ����Ժ�����", "ע����", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == btnLogin) {    //��¼
            // ��ȡ�û�������û���������
            String uname = txtuname.getText().trim();
            String upassword = txtupassword.getText().trim();


            if (checkUser(uname, upassword)) {
                JOptionPane.showMessageDialog(this, "��¼�ɹ�", "��¼���", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "��¼ʧ�ܣ������û���������", "��¼���", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}